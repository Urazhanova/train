import { HeroSection } from "@/components/HeroSection";
import { WhyMigrateSection } from "@/components/WhyMigrateSection";
import { HowItWorksSection } from "@/components/HowItWorksSection";
import { FeaturesComparisonSection } from "@/components/FeaturesComparisonSection";
import { TargetAudienceSection } from "@/components/TargetAudienceSection";
import { ProcessSection } from "@/components/ProcessSection";
import { CTASection } from "@/components/CTASection";

const Index = () => {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <WhyMigrateSection />
      <HowItWorksSection />
      <FeaturesComparisonSection />
      <TargetAudienceSection />
      <ProcessSection />
      <CTASection />
    </main>
  );
};

export default Index;
