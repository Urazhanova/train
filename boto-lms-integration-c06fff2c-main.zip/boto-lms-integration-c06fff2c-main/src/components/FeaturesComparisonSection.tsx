import { Check, Plus } from "lucide-react";

const stayingFeatures = [
  "автоматическая проверка",
  "помощь студентам",
  "модерация",
  "генерация контента",
  "аналитика",
];

const newFeatures = [
  "inline-ответы в заданиях",
  "подсказки внутри уроков",
  "синхронизация с LMS",
  "встроенная аналитика",
  "единый интерфейс без Telegram",
];

export const FeaturesComparisonSection = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-center mb-16 font-bold">
            Всё, что вы любите в Boto — только удобнее
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            {/* Staying Features */}
            <div className="p-10 rounded-3xl bg-white shadow-lg hover:shadow-xl transition-all duration-300 border border-border">
              <h3 className="mb-8 font-bold text-2xl">Остаётся</h3>
              <div className="space-y-5">
                {stayingFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Check className="w-5 h-5 text-primary" />
                    </div>
                    <span className="text-lg text-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* New Features */}
            <div className="p-10 rounded-3xl bg-gradient-to-br from-pastel-1 to-pastel-2 shadow-lg hover:shadow-xl transition-all duration-300 border-2 border-primary/30">
              <h3 className="mb-8 font-bold text-2xl">Добавляется</h3>
              <div className="space-y-5">
                {newFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center flex-shrink-0 shadow-md">
                      <Plus className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-lg text-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
