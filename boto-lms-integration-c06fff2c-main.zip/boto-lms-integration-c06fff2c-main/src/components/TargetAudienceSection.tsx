import { GraduationCap, Building2, BookOpen, Globe } from "lucide-react";

const audiences = [
  {
    icon: GraduationCap,
    text: "университетам",
  },
  {
    icon: Building2,
    text: "корпоративным академиям",
  },
  {
    icon: BookOpen,
    text: "онлайн-школам",
  },
  {
    icon: Globe,
    text: "образовательным платформам",
  },
];

export const TargetAudienceSection = () => {
  return (
    <section className="py-24 md:py-32 bg-secondary">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-center mb-16 font-bold">
            Кому подходит LMS-интеграция
          </h2>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {audiences.map((audience, index) => (
              <div 
                key={index}
                className="p-8 rounded-3xl bg-white text-center shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-border"
              >
                <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary to-[hsl(250,90%,65%)] flex items-center justify-center shadow-lg">
                  <audience.icon className="w-10 h-10 text-white" />
                </div>
                <p className="text-lg font-semibold text-foreground">
                  {audience.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
