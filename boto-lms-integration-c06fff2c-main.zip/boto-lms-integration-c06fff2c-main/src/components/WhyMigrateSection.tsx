import { CheckCircle2, Shield, Users, Layers, Zap } from "lucide-react";

const benefits = [
  {
    icon: CheckCircle2,
    text: "Студенты не покидают учебную среду",
  },
  {
    icon: Layers,
    text: "Единое место для обучения и общения",
  },
  {
    icon: Users,
    text: "Удобно на потоках 100+ студентов",
  },
  {
    icon: Shield,
    text: "Больше безопасности и контроля",
  },
  {
    icon: Zap,
    text: "Глубокая связь Boto со структурой курса",
  },
];

export const WhyMigrateSection = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-center mb-16 font-bold">
            Зачем переходить, если Telegram-бот уже работает?
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {benefits.map((benefit, index) => (
              <div 
                key={index}
                className="flex items-start gap-5 p-8 rounded-3xl bg-white border border-border shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex-shrink-0">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-[hsl(250,90%,65%)] flex items-center justify-center shadow-md">
                    <benefit.icon className="w-7 h-7 text-white" />
                  </div>
                </div>
                <p className="text-lg text-foreground pt-3 leading-relaxed">
                  {benefit.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
