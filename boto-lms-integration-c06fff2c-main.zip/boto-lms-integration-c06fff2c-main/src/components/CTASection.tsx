import { Button } from "@/components/ui/button";
import abstractShapes from "@/assets/abstract-shapes.svg";

export const CTASection = () => {
  return (
    <section className="relative py-32 md:py-40 bg-gradient-to-br from-primary via-[hsl(245,95%,65%)] to-[hsl(250,90%,60%)] overflow-hidden">
      <div 
        className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 h-full opacity-10"
        style={{
          backgroundImage: `url(${abstractShapes})`,
          backgroundSize: 'contain',
          backgroundPosition: 'right center',
          backgroundRepeat: 'no-repeat',
        }}
      />
      
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute bottom-10 right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl mx-auto text-center space-y-10">
          <h2 className="font-bold text-white">
            Хотите увидеть, как это выглядит в вашей LMS?
          </h2>
          
          <div className="pt-4">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 hover:text-primary shadow-2xl hover:shadow-3xl border-0 text-lg px-12">
              Запросить демо
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
