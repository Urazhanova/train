import { Button } from "@/components/ui/button";
import heroIllustration from "@/assets/hero-illustration.svg";

export const HeroSection = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary via-[hsl(245,95%,65%)] to-[hsl(250,90%,60%)]">
      <div 
        className="absolute right-0 top-1/2 -translate-y-1/2 w-1/3 h-2/3 opacity-20"
        style={{
          backgroundImage: `url(${heroIllustration})`,
          backgroundSize: 'contain',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
        }}
      />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h1 className="font-bold leading-tight text-white">
            Теперь Boto работает прямо в вашей LMS
          </h1>
          
          <p className="text-xl md:text-2xl text-white/95 max-w-2xl mx-auto font-semibold">
            Привычная автоматизация. Новый уровень удобства.
          </p>
          
          <div className="pt-4">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 hover:text-primary shadow-xl hover:shadow-2xl border-0">
              Получить демо
            </Button>
          </div>
        </div>
      </div>
      
      {/* Decorative gradient orbs */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
    </section>
  );
};
