import { ArrowRight } from "lucide-react";

const processSteps = [
  "Подключаем Boto к вашей LMS",
  "Переносим настройки и роли",
  "Синхронизируем курсы",
  "Студенты продолжают учиться как обычно",
];

export const ProcessSection = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-center mb-6 font-bold">
            Переход занимает до 3 дней
          </h2>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-8 mt-16">
            {processSteps.map((step, index) => (
              <div key={index} className="flex items-center gap-6 md:gap-8">
                <div className="flex flex-col items-center gap-4 group">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-[hsl(250,90%,65%)] flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300">
                    <span className="text-3xl font-bold text-white">{index + 1}</span>
                  </div>
                  <p className="text-center text-base text-foreground max-w-[160px] font-medium leading-snug">
                    {step}
                  </p>
                </div>
                
                {index < processSteps.length - 1 && (
                  <ArrowRight className="hidden md:block w-10 h-10 text-primary/50 flex-shrink-0" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
