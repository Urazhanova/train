const steps = [
  "Встраиваем AI-модуль прямо в LMS",
  "Проверка, ответы, подсказки — внутри уроков",
  "Синхронизация баллов и статусов",
  "Контекстные подсказки по материалам",
  "Аналитика — без экспорта данных",
];

export const HowItWorksSection = () => {
  return (
    <section className="py-24 md:py-32 bg-gradient-to-b from-secondary to-background">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-center mb-16 font-bold">
            Как работает Boto в LMS
          </h2>
          
          <div className="grid gap-6">
            {steps.map((step, index) => (
              <div 
                key={index}
                className="flex items-center gap-6 p-8 bg-white rounded-3xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-border"
              >
                <div className="flex-shrink-0">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-[hsl(250,90%,65%)] text-white flex items-center justify-center text-2xl font-bold shadow-lg">
                    {index + 1}
                  </div>
                </div>
                <p className="text-lg md:text-xl text-foreground leading-relaxed">
                  {step}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
